package com.example.test2.model

data class admin (var username:String, var email:String, var password:String)