package com.example.test2.model

data class RestaurantRate(
    val rate: Double = 0.0,
    val resid: String = "",
    val review: String = "",
    val userid: String = ""
)