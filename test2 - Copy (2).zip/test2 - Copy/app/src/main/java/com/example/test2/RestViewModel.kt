package com.example.test2

import androidx.lifecycle.ViewModel

class RestViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}