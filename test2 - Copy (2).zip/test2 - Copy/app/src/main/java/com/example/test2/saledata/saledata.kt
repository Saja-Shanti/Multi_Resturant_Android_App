package com.example.test2.saledata

data class saledata(var id:Int, var name:String, var imag:Int)